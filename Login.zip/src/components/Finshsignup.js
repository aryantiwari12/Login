import React from "react";

function Finshsignup() {
    return (
        <div>
            <div className="container bg-white w-25 rounded">
                <div className="picture">
                    <img src={IMAGE} alt="" className="mt-2" />
                </div>
                <div className="name mt-2">
                    <h1>Finsh signing Up</h1>
                </div>
            </div>
        </div>
    );
}
export default Finshsignup;