import React from "react";

function Verfied(){
   return(
    <div>
        <div className="container bg-white w-25 rounded">
                <p>Your phonenumber is susscefully Verfied!</p>
        </div>
    </div>
   );
}
export default Verfied;