import React from "react";

function Emailverfied() {
    return (
        <div>
            <div className="container bg-white w-25 rounded">
                <p>Your email is susscefully Verfied!</p>
            </div>
        </div>
    );
}
export default Emailverfied;